﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Specialized;
using System.Security;
using System.Data.SqlClient;
using LogLibrary;

namespace LoggerApplication
{
    public class Program
    {
        static void Main(string[] args)
        {
            Logger log = new Logger();
            
         //  log.LogData(Logger.LogType.Information, Logger.LogTarget.EventLog, "Completed processing 2125 records");
          //log.LogData(Logger.LogType.Warning, Logger.LogTarget.EventLog, "Upper limit is not available. Proceeding with 0 upper limit");
           log.LogData(Logger.LogType.Error, Logger.LogTarget.EventLog, "Divide by zero encountered");
           
            Console.ReadLine();
        }
    }
}
