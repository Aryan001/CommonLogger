﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Specialized;
using System.Security;
using System.Data.SqlClient;

namespace LogLibrary
{
    public class Logger
    {
        public enum LogType { Information, Warning, Error };
        public enum LogTarget { TextFile, Database, EventLog};
        string textFileToLog=ConfigurationSettings.AppSettings["TextFileToLog"];
        string appNameForEventLog = ConfigurationSettings.AppSettings["AppNameForEventLog"];

        public void LogData(LogType logType, LogTarget logTarget, string dataToLog)
        {
            switch (logTarget)
            {
                case LogTarget.TextFile:
                    {
                        LogIntoTextFile(logType, dataToLog);
                        break;
                    }
                case LogTarget.EventLog:
                    {
                        LogIntoEventLog(logType, dataToLog);
                        break;
                    }
                case LogTarget.Database:
                    {
                        LogIntoDatabase(logType, dataToLog);
                        break;
                    }
            }
        }

        private void LogIntoTextFile(LogType logType, string dataToLog)
        {
            try
            {
                using (System.IO.StreamWriter logFile = new System.IO.StreamWriter(textFileToLog, true))
                {
                    logFile.WriteLine(appNameForEventLog + " " + logType.ToString() + " " + DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss") + " " + dataToLog);
                }
            }
            catch (SqlException ex)
            {
                LogIntoEventLog(logType, "Error while logging the data " + dataToLog + ". Exception is " + ex.Message + ", stack trace is " + ex.StackTrace);
            }
        }  
        
        private void LogIntoEventLog(LogType logType, string dataToLog)
        {
            EventLog eventLog = new EventLog();
            try
            {
                if (!EventLog.SourceExists(appNameForEventLog))
                {
                    EventLog.CreateEventSource(appNameForEventLog, appNameForEventLog);
                }
                eventLog.Source = appNameForEventLog;
                switch (logType)
                {
                    case LogType.Information:
                        {
                            eventLog.WriteEntry(dataToLog, EventLogEntryType.Information, 1000);
                            break;
                        }
                    case LogType.Warning:
                        {
                            eventLog.WriteEntry(dataToLog, EventLogEntryType.Warning, 1001);
                            break;
                        }
                    case LogType.Error:
                        {
                            eventLog.WriteEntry(dataToLog, EventLogEntryType.Error, 1002);
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                eventLog.WriteEntry("Error while logging " + dataToLog + ". Error is " + ex.Message + ". Stack trace is " + ex.StackTrace, EventLogEntryType.Error, 1002);
            }
        }

        private void LogIntoDatabase(LogType logType, string dataToLog)
        {
            string databaseConnectionStringForLogging = ConfigurationSettings.AppSettings["DatabaseConnectionStringForLogging"];
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(databaseConnectionStringForLogging))
                {
                    sqlConnection.Open();
                    string query = "INSERT INTO Log (Logtype, Datetime, Logdata) VALUES ('" + logType.ToString() + "' , '" + DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss") + "' , '" + dataToLog + "')";
                    using (SqlCommand sqlcommand = new SqlCommand(query, sqlConnection))
                    {
                        sqlcommand.ExecuteNonQuery();
                    }
                    sqlConnection.Close();
                }
            }
            catch (SqlException ex)
            {
                LogIntoEventLog(logType, "Error while logging the data " + dataToLog + ". Exception is " + ex.Message + ", stack trace is " + ex.StackTrace);
            }
        }
    }
}
